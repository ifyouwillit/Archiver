<br><div style="clear:both;margin-bottom:5px;"><div style="float: left; width: 230px;padding-left:5px;clear:both;"><a href="#disqus_thread" class="WikiLinks" style="color:pink;">Comments</a></div> 
<div style="float: left; width: 250px;">
						<!-- AddThis Button BEGIN -->
						<div class="addthis_toolbox addthis_default_style ">
							<a class="addthis_button_facebook_like"
								fb:like:layout="button_count"></a> <a
								class="addthis_button_tweet"></a>
						</div>
						<script type="text/javascript">var addthis_config = {"data_track_addressbar":true};</script>
						<script type="text/javascript"
							src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-4d9382c05f7ea37f"></script>
						<!-- AddThis Button END -->
					</div></div>