<?php

//Get Search Query
$q=urldecode($_GET['q']);
$originalsearch=urlencode($_GET['originalsearch']);
$searchtype=$_GET['searchtype'];
?>
