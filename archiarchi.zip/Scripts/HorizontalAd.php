<center>
<script type="text/javascript">
clicksor_mobile_redirect = false;
//default banner house ad url 
clicksor_default_url = '';
clicksor_banner_border = '#A0D000'; clicksor_banner_ad_bg = '#FFFFFF';
clicksor_banner_link_color = '#000000'; clicksor_banner_text_color = '#666666';
clicksor_banner_image_banner = true; clicksor_banner_text_banner = true;
clicksor_layer_border_color = '#A0D000';
clicksor_layer_ad_bg = '#FFFFFF'; clicksor_layer_ad_link_color = '#000000';
clicksor_layer_ad_text_color = '#666666'; clicksor_text_link_bg = '';
clicksor_text_link_color = ''; clicksor_enable_text_link = false;
clicksor_layer_banner = false;
</script>
<script type="text/javascript" src="http://ads.clicksor.com/newServing/showAd.php?nid=1&amp;pid=232159&amp;adtype=2&amp;sid=542542"></script>
<noscript><a href="http://www.yesadvertising.com">affiliate marketing</a></noscript>
</center>