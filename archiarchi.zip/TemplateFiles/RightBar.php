<div style="padding:10px;background-color:#000000;color:#ffffff;font-weight:bold;">
Search
</div>
<div class="SearchBox"><form method="get" action="Search.php"><input id="q" name="q" value="<? if ($_GET['q']){ echo $q; } else { echo "Search..."; }?>" class="SearchBar" onclick="if(this.value!=''){this.value=''}" onblur="if(this.value==''){this.value='Search...'}"></form></div>
<br>
<div style="padding:10px;background-color:#000000;color:#ffffff;font-weight:bold;">
Sponsors
</div>
<div style="padding:0px;background-color:#222222;">

<!-- ArchiverRight -->
<div id='div-gpt-ad-1337201116512-0' style='width:300px; height:250px;'>
<script type='text/javascript'>
googletag.cmd.push(function() { googletag.display('div-gpt-ad-1337201116512-0'); });
</script>
</div>

</div>
<br>
<div style="padding:10px;background-color:#000000;color:#ffffff;font-weight:bold;">
On Facebook
</div>
<div style="padding:10px;background-color:#222222;">
<div class="fb-like-box" data-href="https://www.facebook.com/socialarchive" data-width="280" data-show-faces="true" data-colorscheme="dark" data-stream="false" data-border-color="#000000" data-header="false"></div>
</div>
<br>
<div style="padding:10px;background-color:#000000;color:#ffffff;font-weight:bold;">
Comments
</div>
<div style="padding:10px;background-color:#222222;">
<div class="fb-comments" data-href="<?=curPageURL();?>" data-width="280" data-num-posts="2" data-colorscheme="dark"></div>
</div>