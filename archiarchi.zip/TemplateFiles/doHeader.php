<?php
error_reporting(E_ERROR);
include 'Configuration/getQuery.php';
include 'Sources/GetDataSources.php';
?>
<script type="text/javascript">
 var oneall_js_protocol = (("https:" == document.location.protocol) ? "https" : "http");
 document.write(unescape("%3Cscript src='" + oneall_js_protocol + "://archiver.api.oneall.com/socialize/library.js' type='text/javascript'%3E%3C/script%3E"));
</script>