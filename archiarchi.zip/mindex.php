<link rel="stylesheet" type="text/css" href="CSS/menu_style.css" />
<div style="width:100%;clear:both;">
<div class="topbutton1"><a href="LiveStream.php" class="toplink">Bitline</a></div>
<div class="topbutton"><a href="Category/Art.htm" class="toplink">Art</a></div>
<div class="topbutton"><a href="Category/Entertainment.htm" class="toplink">Entertainment</a></div>
<div class="topbutton"><a href="Category/Geography.htm" class="toplink">Geography</a></div>
<div class="topbutton"><a href="Category/Lifestyle.htm" class="toplink">Lifestyle</a></div>
<div class="topbutton"><a href="Category/Math.htm" class="toplink">Math</a></div>
<div class="topbutton"><a href="Category/Music.htm" class="toplink">Music</a></div>
<div class="topbutton"><a href="Category/News.htm" class="toplink">News</a></div>
<div class="topbutton"><a href="Category/Science.htm" class="toplink">Science</a></div>
<div class="topbutton"><a href="Category/Shopping.htm" class="toplink">Shopping</a></div>
<div class="topbutton"><a href="Category/Tags.htm" class="toplink">Tags</a></div>
<div class="topbutton"><a href="Category/Technology.htm" class="toplink">Technology</a></div>
<div class="topbutton"><a href="Category/Transportation.htm" class="toplink">Transportation</a></div>
</div>
<div style="width:100%;clear:both;"></div>